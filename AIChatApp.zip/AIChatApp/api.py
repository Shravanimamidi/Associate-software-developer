from fastapi import FastAPI, UploadFile, Form
from pdf_processor import PDFProcessor
from rag_model import RAGModel

app = FastAPI()
pdf_processor = PDFProcessor()
rag_model = RAGModel(pdf_processor)

@app.post("/upload/")
async def upload_pdf(file: UploadFile):
    file_content = await file.read()
    with open(f"temp_{file.filename}", "wb") as f:
        f.write(file_content)
    pdf_processor.process_pdf(f"temp_{file.filename}")
    pdf_processor.embed_text()
    return {"message": "PDF uploaded and processed successfully"}

@app.get("/query/")
async def query_answer(query: str):
    answer = rag_model.get_answer(query)
    return {"answer": answer}
